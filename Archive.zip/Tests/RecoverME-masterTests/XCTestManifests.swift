import XCTest

#if !canImport(ObjectiveC)
public func allTests() -> [XCTestCaseEntry] {
    return [
        testCase(RecoverME_masterTests.allTests),
    ]
}
#endif
