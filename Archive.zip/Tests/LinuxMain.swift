import XCTest

import RecoverME_masterTests

var tests = [XCTestCaseEntry]()
tests += RecoverME_masterTests.allTests()
XCTMain(tests)
