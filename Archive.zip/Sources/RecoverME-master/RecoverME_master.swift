struct RecoverME_master {
    var text = "Hello, World!"
}
