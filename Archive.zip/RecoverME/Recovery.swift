//
//  Recovery.swift
//  RecoverME
//
//  Created by Nic Dillon on 4/18/19.
//  Copyright © 2019 Nic Dillon. All rights reserved.
//

import Foundation

class Recovery {
    //MARK: Atributes
    var protein = 0
    var carb = 0
    var fat = 0
    var water = 0
    
    //MARK: Actions
    
}
