//
//  Workout.swift
//  RecoverME
//
//  Created by Nic Dillon on 4/18/19.
//  Copyright © 2019 Nic Dillon. All rights reserved.
//

import Foundation

class Workout {
    
    //MARK: Atributes
    var time = 0
    var calories = 0
    var type: String?
    
    //MARK: Actions
    
    
    
}
