//
//  HomeViewController.swift
//  RecoverME
//
//  Created by Nic Dillon on 4/18/19.
//  Copyright © 2019 Nic Dillon. All rights reserved.
//

import Foundation

class User {
    
    //MARK: Attributes
    var height = 0
    var weight = 0
    var goal = 0
    var date = 0
    var email: String?
    var password: String?
    //MARK: Actions
    
    
}


